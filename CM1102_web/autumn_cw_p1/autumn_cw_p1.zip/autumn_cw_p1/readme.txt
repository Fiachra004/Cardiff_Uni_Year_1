Name: Fiachra Bermingham
Student Number: 23054106
Email: BerminghamF@cardiff.ac.uk
Website: https://project.cs.cf.ac.uk/BerminghamF/autumn_cw_p1/Terry_Davis.html